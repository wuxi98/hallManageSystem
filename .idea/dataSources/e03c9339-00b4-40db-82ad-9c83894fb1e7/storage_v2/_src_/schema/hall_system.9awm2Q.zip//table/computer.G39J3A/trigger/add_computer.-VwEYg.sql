create trigger add_computer
  after INSERT
  on computer
  for each row
  BEGIN
	update hall
	set computer_number=computer_number+1
	where hall_id=new.hall_id;
    END;

