create trigger status_both_time
  after UPDATE
  on student_log
  for each row
  BEGIN
	 UPDATE student
	 SET TOTAL_TIME=TOTAL_TIME+(UNIX_TIMESTAMP(NEW.end_time) -  UNIX_TIMESTAMP(NEW.start_time))/3600
	 WHERE student_id=new.student_id and new.isfree!=1 and new.end_time is not null;
	update computer
	 SET used_time=used_time+(UNIX_TIMESTAMP(NEW.end_time) -  UNIX_TIMESTAMP(NEW.start_time))/3600,
	 `computer_status`='空闲'
	 WHERE computer_id=new.computer_id AND new.end_time IS not NULL;
	 
	
	 
    END;

