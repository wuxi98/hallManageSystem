create trigger status_change_by_go_computer
  after INSERT
  on student_log
  for each row
  BEGIN
	update computer
	set `computer_status`='使用'
	where computer_id=new.computer_id;
    END;

