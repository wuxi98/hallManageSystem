create view v_hall_manager_login_log as
  select
    `hall_system`.`hall_manager`.`hall_manager_id`   AS `hall_manager_id`,
    `hall_system`.`hall_manager`.`hall_manager_name` AS `hall_manager_name`,
    `hall_system`.`hall_manager_log`.`start_time`    AS `start_time`,
    `hall_system`.`hall_manager_log`.`finish_time`   AS `finish_time`,
    `hall_system`.`hall_manager_log`.`ip`            AS `ip`
  from (`hall_system`.`hall_manager`
    join `hall_system`.`hall_manager_log`)
  where (`hall_system`.`hall_manager`.`hall_manager_id` = `hall_system`.`hall_manager_log`.`hall_manager_id`);

