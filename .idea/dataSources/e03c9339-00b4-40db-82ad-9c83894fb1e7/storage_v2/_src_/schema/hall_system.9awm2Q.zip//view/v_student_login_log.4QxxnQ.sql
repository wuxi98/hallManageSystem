create view v_student_login_log as
  select
    `hall_system`.`student`.`student_id`      AS `student_id`,
    `hall_system`.`student`.`student_name`    AS `student_name`,
    `hall_system`.`student_log`.`start_time`  AS `start_time`,
    `hall_system`.`student_log`.`end_time`    AS `end_time`,
    `hall_system`.`student_log`.`isfree`      AS `isfree`,
    `hall_system`.`student_log`.`computer_id` AS `computer_id`,
    `hall_system`.`student_log`.`ip`          AS `ip`
  from (`hall_system`.`student`
    join `hall_system`.`student_log`)
  where (`hall_system`.`student`.`student_id` = `hall_system`.`student_log`.`student_id`);

